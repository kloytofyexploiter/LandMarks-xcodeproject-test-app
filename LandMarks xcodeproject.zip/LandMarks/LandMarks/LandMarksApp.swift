//
//  LandMarksApp.swift
//  LandMarks
//
//  Created by Mattias K Larsen on 27/11/2022.
//

import SwiftUI

@main
struct LandMarksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
