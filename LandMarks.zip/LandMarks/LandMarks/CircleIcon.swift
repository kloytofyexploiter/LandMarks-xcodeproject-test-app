//
//  CircleIcon.swift
//  LandMarks
//
//  Created by Mattias k Larsen on 28/11/2022.
//

import SwiftUI

struct CircleIcon: View {
    var body: some View {
        Image("turtlerock")
    }
}

struct CircleIcon_Previews: PreviewProvider {
    static var previews: some View {
        CircleIcon()
    }
}
